#include <types.h>
#include <boot.h>
#include <list.h>
#include <paging.h>

#include <x86-64/asm.h>

#include <kernel/mem.h>
#include <kernel/tests.h>

extern struct list buddy_free_list[];

/* The kernel's initial PML4. */
struct page_table *kernel_pml4;
struct page_info *kernel_pml4_page;
/* This function sets up the initial PML4 for the kernel. */
int pml4_setup(struct boot_info *boot_info)
{
	struct page_info *page;

	/* Allocate the kernel PML4. */
	kernel_pml4_page = page_alloc(ALLOC_ZERO);

	if (!kernel_pml4_page) {
		panic("unable to allocate the PML4!");
	}

	kernel_pml4 = page2kva(kernel_pml4_page);

	uint64_t kflags = PAGE_PRESENT;

	/* Map in the regions used by the kernel from the ELF header passed to
	 * us through the boot info struct.
	 */

	/* LAB 2: your code here. */
	boot_map_kernel(kernel_pml4, (struct elf*) boot_info->elf_hdr);
	
	//debug_print2();

	//dump_page_tables(kernel_pml4, 0);
	//panic("end");
	/* Use the physical memory that 'bootstack' refers to as the kernel
	 * stack. The kernel stack grows down from virtual address KSTACK_TOP.
	 * Map 'bootstack' to [KSTACK_TOP - KSTACK_SIZE, KSTACK_TOP).
	 */
	boot_map_region(kernel_pml4, (void*)(KSTACK_TOP - KSTACK_SIZE), KSTACK_SIZE, (physaddr_t) bootstack, kflags);


	/* Map in the pages from the buddy allocator as RW-. */
	

	/* LAB 2: your code here. */
	//map all the occupied pages from the buddy allocator

	boot_map_region(kernel_pml4, (void*) KPAGES, npages * sizeof(struct page_info), PADDR(pages), kflags);
	//debug_print2();
	//todo map later the other regions of memory like process map etc.

	/* Migrate the struct page_info structs to the newly mapped area using
	 * buddy_migrate().
	 */
	//panic("debug");
	/* LAB 2: your code here. */
	buddy_migrate();
	return 0;
}

/*
 * Set up a four-level page table:
 * kernel_pml4 is its linear (virtual) address of the root
 *
 * This function only sets up the kernel part of the address space (i.e.
 * addresses >= USER_TOP). The user part of the address space will be set up
 * later.
 *
 * From USER_TOP to USER_LIM, the user is allowed to read but not write.
 * Above USER_LIM, the user cannot read or write.
 */
void mem_init(struct boot_info *boot_info)
{
	struct mmap_entry *entry;
	uintptr_t highest_addr = 0;
	uint32_t cr0;
	size_t i, n;

	/* Align the areas in the memory map. */
	align_boot_info(boot_info);

	/* Set up the buddy free lists. */
	for (i = 0; i < BUDDY_MAX_ORDER; ++i) {
		list_init(buddy_free_list + i);
	};

	/* Find the amount of pages to allocate structs for. */
	entry = (struct mmap_entry *)((physaddr_t)boot_info->mmap_addr);

	for (i = 0; i < boot_info->mmap_len; ++i, ++entry) {
		if (entry->type != MMAP_FREE)
			continue;

		highest_addr = entry->addr + entry->len;
	}

	/* Limit the struct page_info array to the first 8 MiB, as the rest is
	 * still not accessible until lab 2.
	 */
	npages = MIN(BOOT_MAP_LIM, highest_addr) / PAGE_SIZE;

	/* Remove this line when you're ready to test this function. */
	//panic("mem_init: This function is not finished\n");

	/*
	 * Allocate an array of npages 'struct page_info's and store it in 'pages'.
	 * The kernel uses this array to keep track of physical pages: for each
	 * physical page, there is a corresponding struct page_info in this array.
	 * 'npages' is the number of physical pages in memory.  Your code goes here.
	 */
	pages = boot_alloc(npages * sizeof *pages);


	/*
	 * Now that we've allocated the initial kernel data structures, we set
	 * up the list of free physical pages. Once we've done so, all further
	 * memory management will go through the page_* functions. In particular, we
	 * can now map memory using boot_map_region or page_insert.
	 */
	page_init(boot_info);

	/* Setup the initial PML4 for the kernel. */
	pml4_setup(boot_info);

	/* Enable the NX-bit. */
	/* LAB 2: your code here. */

	uint64_t efer = read_msr(MSR_EFER);
	write_msr(MSR_EFER, efer | MSR_EFER_NXE);

	dump_page_tables(kernel_pml4, PAGE_PRESENT);

	//panic("debug panic");
	/* Check the kernel PML4. */
	lab2_check_pml4();

	/* Load the kernel PML4. */
	/* LAB 2: your code here. */



	cprintf("attempting to load pml4\n");load_pml4((void*)(PADDR(kernel_pml4)));
	cprintf("loaded pml4 in cr3. pa: %p\n", PADDR(kernel_pml4));

	cprintf("loaded pml4");
	/* Check the paging functions. */
	lab2_check_paging();

	cprintf("starting page init ext\n");
	/* Add the rest of the physical memory to the buddy allocator. */
	page_init_ext(boot_info);
	cprintf("page init ext complete\n");
	/* Check the buddy allocator. */
	lab2_check_buddy(boot_info);
}

/*
 * Initialize page structure and memory free list. After this is done, NEVER
 * use boot_alloc() again. After this function has been called to set up the
 * memory allocator, ONLY the buddy allocator should be used to allocate and
 * free physical memory.
 */
void page_init(struct boot_info *boot_info)
{
	struct page_info *page;
	struct mmap_entry *entry;
	uintptr_t pa, end;
	size_t i;

	/* Go through the array of struct page_info structs and:
	 *  1) call list_init() to initialize the linked list node.
	 *  2) set the reference count pp_ref to zero.
	 *  3) mark the page as in use by setting pp_free to zero.
	 *  4) set the order pp_order to zero.
	 */

	for (i = 0; i < npages; ++i) {
		page = pages + i;
		list_init(&page->pp_node);
		page->pp_ref = 0;
		page->pp_free = false;
		page->pp_order = 0;
	}

	entry = (struct mmap_entry *)KADDR(boot_info->mmap_addr);
	end = PADDR(boot_alloc(0));

	/* Go through the entries in the memory map:
	 *  1) Ignore the entry if the region is not free memory.
	 *  2) Iterate through the pages in the region.
	 *  3) If the physical address is above BOOT_MAP_LIM, ignore.
	 *  4) Hand the page to the buddy allocator by calling page_free() if
	 *     the page is not reserved.
	 *
	 * What memory is reserved?
	 *  - Address 0 contains the IVT and BIOS data.
	 *  - boot_info->elf_hdr points to the ELF header.
	 *  - Any address in [KERNEL_LMA, end) is part of the kernel.
	 */
	for (i = 0; i < boot_info->mmap_len; ++i, ++entry) {

		if((entry->type & MMAP_FREE) == 0){
			continue;
		}
		for(physaddr_t i = entry->addr; i < ROUNDDOWN(entry->addr + entry->len, PAGE_SIZE); i += PAGE_SIZE){
			
			if(i + PAGE_SIZE > BOOT_MAP_LIM){
				break;
			}
			if(i == 0){
				continue;
			}
			if(i == (physaddr_t)boot_info->elf_hdr){
				continue;
			}
			if(i >= KERNEL_LMA && i < (uint64_t)end){
				continue;
			}
			if(i == PAGE_ADDR(PADDR(boot_info))){
				continue;
			}
			size_t page_index = i >> 12;

			page_free(pages + page_index);
		}
	}
}
/* Extend the buddy allocator by initializing the page structure and memory
 * free list for the remaining available memory.
 */
void page_init_ext(struct boot_info *boot_info)
{
	struct page_info *page;
	struct mmap_entry *entry;
	uintptr_t pa, end;
	size_t i;

	entry = (struct mmap_entry *)KADDR(boot_info->mmap_addr);
	end = PADDR(boot_alloc(0));

	/* Go through the entries in the memory map:
	 *  1) Ignore the entry if the region is not free memory.
	 *  2) Iterate through the pages in the region.
	 *  3) If the physical address is below BOOT_MAP_LIM, ignore.
	 *  4) Hand the page to the buddy allocator by calling page_free().
	 */
	for (i = 0; i < boot_info->mmap_len; ++i, ++entry) {
		if(entry->type != MMAP_FREE) continue;

		for(physaddr_t addr = entry->addr; addr < entry->addr + entry->len; addr += PAGE_SIZE){
			if(addr < BOOT_MAP_LIM) continue;
			
			if(PAGE_INDEX(addr) >= npages){
				buddy_map_chunk(kernel_pml4, PAGE_INDEX(addr));
			}

			struct page_info* page = pa2page(addr);

			list_init(&page->pp_node);
			page->pp_ref = 0;
			page->pp_free = false;
			page->pp_order = 0;

			page_free(pa2page(addr));

		}
	}
}
