#include <error.h>
#include <string.h>
#include <paging.h>
#include <task.h>
#include <cpu.h>

#include <kernel/monitor.h>
#include <kernel/mem.h>
#include <kernel/sched.h>

pid_t pid_max = 1 << 16;
struct task **tasks = (struct task **)PIDMAP_BASE;
size_t nuser_tasks = 0;

/* Looks up the respective task for a given PID.
 * If check_perm is non-zero, this function checks if the PID maps to the
 * current task or if the current task is the parent of the task that the PID
 * maps to.
 */
struct task *pid2task(pid_t pid, int check_perm)
{
	struct task *task;

	/* PID 0 is the current task. */
	if (pid == 0) {
		return cur_task;
	}

	/* Limit the PID. */
	if (pid >= pid_max) {
		return NULL;
	}

	/* Look up the task in the PID map. */
	task = tasks[pid];

	/* No such mapping found. */
	if (!task) {
		return NULL;
	}

	/* If we don't have to do a permission check, we can simply return the
	 * task.
	 */
	if (!check_perm) {
		return task;
	}

	/* Check if the task is the current task or if the current task is the
	 * parent. If not, then the current task has insufficient permissions.
	 */
	if (task != cur_task && task->task_ppid != cur_task->task_pid) {
		return NULL;
	}

	return task;
}

void task_init(void)
{
	/* Allocate an array of pointers at PIDMAP_BASE to be able to map PIDs
	 * to tasks.
	 */
	populate_region(kernel_pml4, (void*) PIDMAP_BASE, ROUNDUP(pid_max * sizeof(struct task *), PAGE_SIZE), 
						PAGE_PRESENT | PAGE_WRITE | PAGE_NO_EXEC);
}

/* Sets up the virtual address space for the task. */
static int task_setup_vas(struct task *task)
{
	struct page_info *page;

	/* Allocate a page for the page table. */
	page = page_alloc(ALLOC_ZERO);

	if (!page) {
		return -ENOMEM;
	}

	++page->pp_ref;

	/* Now set task->task_pml4 and initialize the page table.
	 * Can you use kernel_pml4 as a template?
	 */
	struct page_table *user_pml4 = page2kva(page);

	for(int i = PML4_INDEX(KERNEL_VMA); i < PAGE_TABLE_ENTRIES; i++){
		user_pml4->entries[i] = kernel_pml4->entries[i];
	}
	task->task_pml4 = user_pml4;

	assert(!page_lookup(task->task_pml4, (void*) 0x804000, NULL));

	
	/* LAB 3: your code here. */
	return 0;
}

/* Allocates and initializes a new task.
 * On success, the new task is returned.
 */
struct task *task_alloc(pid_t ppid)
{
	struct task *task;
	pid_t pid;

	/* Allocate a new task struct. */
	task = kmalloc(sizeof *task);

	if (!task) {
		return NULL;
	}

	/* Set up the virtual address space for the task. */
	if (task_setup_vas(task) < 0) {
		kfree(task);
		return NULL;
	}

	/* Find a free PID for the task in the PID mapping and associate the
	 * task with that PID.
	 */
	for (pid = 1; pid < pid_max; ++pid) {
		if (!tasks[pid]) {
			tasks[pid] = task;
			task->task_pid = pid;
			break;
		}
	}
	/* We are out of PIDs. */
	if (pid == pid_max) {
		kfree(task);
		return NULL;
	}

	/* Set up the task. */
	task->task_ppid = ppid;
	task->task_type = TASK_TYPE_USER;
	task->task_status = TASK_RUNNABLE;
	task->task_runs = 0;

	memset(&task->task_frame, 0, sizeof task->task_frame);

	task->task_frame.ds = GDT_UDATA | 3;
	task->task_frame.ss = GDT_UDATA | 3;
	task->task_frame.rsp = USTACK_TOP;
	task->task_frame.cs = GDT_UCODE | 3;
	/* You will set task->task_frame.rip later. */
	cprintf("[PID %5u] New task with PID %u\n",
	        cur_task ? cur_task->task_pid : 0, task->task_pid);

	task->task_wait = NULL;
	return task;
}

/* Sets up the initial program binary, stack and processor flags for a user
 * process.
 * This function is ONLY called during kernel initialization, before running
 * the first user-mode environment.
 *
 * This function loads all loadable segments from the ELF binary image into the
 * task's user memory, starting at the appropriate virtual addresses indicated
 * in the ELF program header.
 * At the same time it clears to zero any portions of these segments that are
 * marked in the program header as being mapped but not actually present in the
 * ELF file, i.e., the program's .bss section.
 *
 * All this is very similar to what our boot loader does, except the boot
 * loader also needs to read the code from disk. Take a look at boot/main.c to
 * get some ideas.
 *
 * Finally, this function maps one page for the program's initial stack.
 */
void debug_print(struct page_table *pml4){

	for(int i = 0; i < PAGE_TABLE_ENTRIES; i++){
		physaddr_t entry = pml4->entries[i];

		if(entry == 0)continue;

		cprintf("entry: %d: %p\n", i, entry);

		for(int j = 0; j < PAGE_TABLE_ENTRIES; j++){
			struct page_table *pdpt = KADDR(PAGE_ADDR(entry));
			physaddr_t entry2 = pdpt->entries[j];

			if(entry2 == 0)continue;

			cprintf("	entry2: %d %p\n", j, entry2);

			for(int k = 0; k < PAGE_TABLE_ENTRIES; k++){
				struct page_table *pdir = KADDR(PAGE_ADDR(entry2));
				physaddr_t entry3 = pdir->entries[k];
				if(entry3 == 0)continue;

				if(entry3 & PAGE_HUGE){
					cprintf("		HUGE PAGE %d %p\n", k, entry3);
					continue;
				}		
				cprintf("		entry3 %d %p\n", k, entry3);
				for(int l = 0; l < PAGE_TABLE_ENTRIES; l++){
					struct page_table *ptbl = KADDR(PAGE_ADDR(entry3));
					physaddr_t entry4 = ptbl->entries[l];

					if(entry4 == 0)continue;
					cprintf("			entry %d %p\n", l, entry4);
				}
			}
		}
	}
}
void debug_va_to_idx(uintptr_t va){
	cprintf("va: %p is found at: pml4: %d pdpt: %d  pdir %d ptbl %d\n", va, PML4_INDEX(va) % 512, PDPT_INDEX(va) % 512, PAGE_DIR_INDEX(va) % 512, PAGE_INDEX(va) % 512);
}


static void task_load_elf(struct task *task, uint8_t *binary)
{
	/* Hints:
	 * - Load each program segment into virtual memory at the address
	 *   specified in the ELF section header.
	 * - You should only load segments with type ELF_PROG_LOAD.
	 * - Each segment's virtual address can be found in p_va and its
	 *   size in memory can be found in p_memsz.
	 * - The p_filesz bytes from the ELF binary, starting at binary +
	 *   p_offset, should be copied to virtual address p_va.
	 * - Any remaining memory bytes should be zero.
	 * - Use populate_region() and protect_region().
	 * - Check for malicious input.
	 *
	 * Loading the segments is much simpler if you can move data directly
	 * into the virtual addresses stored in the ELF binary.
	 * So in which address space should we be operating during this
	 * function?
	 *
	 * You must also do something with the entry point of the program, to
	 * make sure that the task starts executing there.
	 */

	struct elf *elf = (struct elf *)binary;
	if (elf->e_magic != ELF_MAGIC) {
		panic("binary has wrong magic number. got: %d, expected: %d", elf->e_magic, ELF_MAGIC);
	}
	struct elf_proghdr *prog_headers = (struct elf_proghdr *)(binary + elf->e_phoff);
	assert(elf->e_phoff != 0);

	load_pml4((struct page_table*)PADDR(task->task_pml4));

	for(int i = 0; i < elf->e_phnum; i++){
		struct elf_proghdr *ph = &prog_headers[i];
		if(!(ph->p_type & ELF_PROG_LOAD)){
			continue;
		}
		if(ph->p_va == 0 || ph->p_memsz == 0){
			continue;
		}

		assert(ph->p_offset != 0);
		physaddr_t flags = PAGE_PRESENT | PAGE_USER;
		if(ph->p_flags & ELF_PROG_FLAG_WRITE) flags |= PAGE_WRITE | PAGE_NO_EXEC;

		if(!(ph->p_flags & ELF_PROG_FLAG_EXEC)){
			flags |= PAGE_NO_EXEC;
		} 
		if(ph->p_va + ph->p_memsz >= KERNEL_VMA){
			panic("elf section maps to kernel memory");
		}
		if(ph->p_memsz < ph->p_filesz && ph->p_filesz > 0){
			panic("not enough data in file to write to memory");
		}
		populate_region(task->task_pml4, (void*)ph->p_va, ph->p_memsz, flags);
		//protect_region(task->task_pml4, (void*)ph->p_va, ph->p_memsz, flags);
		if(ph->p_filesz > 0){
			assert(ph->p_filesz == ph->p_memsz);
			memcpy((void*)ph->p_va, binary + ph->p_offset, ph->p_filesz);
		}
		else{
			memset((void*)ph->p_va, 0, ph->p_memsz);
		}
		
	}
	load_pml4((void*)PADDR(kernel_pml4));

	/* Now map one page for the program's initial stack at virtual address
	 * USTACK_TOP - PAGE_SIZE.
	 */
	populate_region(task->task_pml4, (void*)USTACK_TOP - PAGE_SIZE, PAGE_SIZE, PAGE_PRESENT | PAGE_WRITE | PAGE_USER | PAGE_NO_EXEC);
	//protect_region(task->task_pml4, (void*)USTACK_TOP - PAGE_SIZE, PAGE_SIZE, PAGE_PRESENT | PAGE_WRITE | PAGE_USER | PAGE_NO_EXEC);
	task->task_frame.rip = elf->e_entry;
}

/* Allocates a new task with task_alloc(), loads the named ELF binary using
 * task_load_elf() and sets its task type.
 * If the task is a user task, increment the number of user tasks.
 * This function is ONLY called during kernel initialization, before running
 * the first user-mode task.
 * The new task's parent PID is set to 0.
 */
void task_create(uint8_t *binary, enum task_type type)
{
	struct task* task = task_alloc(0);
	
	if(!task)return;
	
	task_load_elf(task, binary);
	task->task_type = type;

	if(type == TASK_TYPE_USER)nuser_tasks++;
	task->task_ppid = 0;
}

/* Free the task and all of the memory that is used by it.
 */
void task_free(struct task *task)
{
	struct task *waiting;
	/* If we are freeing the current task, switch to the kernel_pml4
	 * before freeing the page tables, just in case the page gets re-used.
	 */
	if (task == cur_task) {
		load_pml4((struct page_table *)PADDR(kernel_pml4));
	}

	/* Unmap the task from the PID map. */
	tasks[task->task_pid] = NULL;

	/* Unmap the user pages. */
	unmap_user_pages(task->task_pml4);

	/* Note the task's demise. */
	cprintf("[PID %5u] Freed task with PID %u\n", cur_task ? cur_task->task_pid : 0,
		task->task_pid);

	/* Free the task. */
	kfree(task);
}

/* Frees the task. If the task is the currently running task, then this
 * function runs a new task (and does not return to the caller).
 */
void task_destroy(struct task *task)
{
	task_free(task);
	cprintf("Destroyed the only task - nothing more to do!\n");

	while (1) {
		monitor(NULL);
	}
}

/*
 * Restores the register values in the trap frame with the iretq or sysretq
 * instruction. This exits the kernel and starts executing the code of some
 * task.
 *
 * This function does not return.
 */
void task_pop_frame(struct int_frame *frame)
{
	switch (frame->int_no) {
#ifdef LAB3_SYSCALL
	case 0x80: sysret64(frame); break;
#endif
	default: iret64(frame); break;
	}

	panic("We should have gone back to userspace!");
}

/* Context switch from the current task to the provided task.
 * Note: if this is the first call to task_run(), cur_task is NULL.
 *
 * This function does not return.
 */
void task_run(struct task *task)
{
	assert(task);
	/*
	 * Step 1: If this is a context switch (a new task is running):
	 *     1. Set the current task (if any) back to
	 *        TASK_RUNNABLE if it is TASK_RUNNING (think about
	 *        what other states it can be in),
	 *     2. Set 'cur_task' to the new task,
	 *     3. Set its status to TASK_RUNNING,
	 *     4. Update its 'task_runs' counter,
	 *     5. Use load_pml4() to switch to its address space.
	 * Step 2: Use task_pop_frame() to restore the task's
	 *     registers and drop into user mode in the
	 *     task.
	 *
	 * Hint: This function loads the new task's state from
	 *  e->task_frame.  Go back through the code you wrote above
	 *  and make sure you have set the relevant parts of
	 *  e->task_frame to sensible values.
	 */
	if(cur_task != task){
		assert(task->task_status == TASK_RUNNABLE);
		struct task * old_task = cur_task;
		
		if(cur_task){
			switch (cur_task->task_status)
			{
			case TASK_DYING:{
				task_destroy(cur_task);
				break;
			}
			case TASK_RUNNABLE:{
				panic("runnable task running! forgot to set to running?");
				break;
			}
			case TASK_RUNNING:{
				cur_task->task_status = TASK_RUNNABLE;
				break;
			}
			case TASK_NOT_RUNNABLE:{
				panic("cant get here in lab3");
			}		
			default:
				panic("unknown task state in task_run");
				break;
			}
		}

		cur_task = task;
		cur_task->task_status = TASK_RUNNING;
		cur_task->task_runs++;
		load_pml4((struct page_table*)PADDR(cur_task->task_pml4));
	}

	task_pop_frame(&cur_task->task_frame);
}